from utils.extract import fetch_product_data
from utils.transform import clean_product_data
from utils.load import save_to_csv, save_to_google_sheets, load_to_postgresql

def main():
    base_url = 'https://fashion-studio.dicoding.dev/'
    all_products = []

    print(f"Memulai proses scraping dari halaman awal: {base_url}")
    try:
        products = fetch_product_data(base_url)
        all_products.extend(products)
    except Exception as e:
        print(f"Gagal mengambil data dari halaman utama:  {e}")

    # Lanjut scraping dari halaman 2 sampai 50
    for page_number in range(2, 51):
        page_url = f"{base_url}page{page_number}"
        print(f"Mengakses halaman {page_number}: {page_url}")
        try:
            products = fetch_product_data(page_url)
            all_products.extend(products)
        except Exception as e:
            print(f"Gagal mengambil data dari halaman {page_number}: {e}")

    # Hentikan program jika tidak ada data yang berhasil dikumpulkan
    if not all_products:
        print("Tidak ditemukan data produk yang valid. Proses dihentikan.")
        return

    # Bersihkan dan susun ulang data yang berhasil dikumpulkan
    transformed_data = clean_product_data(all_products)

    # Simpan ke file CSV, database PostgreSQL, dan Google Sheets
    save_to_csv(transformed_data)
    load_to_postgresql(transformed_data)
    save_to_google_sheets(
    transformed_data,
    spreadsheet_id='16REIsNTCTcxa40qXJRFJhTCE3YcxEj65wq_msGIbU0Q'
    )


if __name__ == '__main__':
    main()