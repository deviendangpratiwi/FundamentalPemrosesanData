import sys
import os
import unittest
from unittest.mock import patch, MagicMock
from utils.extract import fetch_product_data  # Ganti 'scrape_main' dengan 'fetch_product_data'


# Tambahkan direktori utama proyek ke dalam path Python
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

class TestExtract(unittest.TestCase):
    @patch('utils.extract.requests.get')
    def test_fetch_product_data_success(self, mock_get):
        """Uji coba jika fungsi fetch_product_data berhasil memproses HTML yang valid."""
        url = "https://fashion-studio.dicoding.dev/"
        # Siapkan response palsu (mocked HTML)
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.text = """
        <html>
            <body>
                <div class="collection-card">
                    <h3 class="product-title">Test Product</h3>
                    <div class="price-container">$10</div>
                    <p>Rating: 5 stars</p>
                    <p>Colors: Red, Blue</p>
                    <p>Size: M, L</p>
                    <p>Gender: Unisex</p>
                </div>
            </body>
        </html>
        """
        mock_get.return_value = mock_response

        # Jalankan fungsi yang diuji
        result = fetch_product_data(url)

        # Verifikasi hasil
        self.assertIsInstance(result, list) # Harus mengembalikan list
        self.assertGreater(len(result), 0) # Minimal ada 1 produk
        self.assertIn('title', result[0]) # Data memiliki field 'title'
        self.assertEqual(result[0]['title'], 'Test Product') # Nama produk sesuai data mock

    @patch('utils.extract.requests.get')
    def test_fetch_product_data_failure(self, mock_get):
        """Uji coba untuk kondisi saat request mengalami error (misal 404)."""
        url = "https://fashion-studio.dicoding.dev/"
        # Simulasikan respons error dari server
        mock_response = MagicMock()
        mock_response.status_code = 404
        mock_response.raise_for_status.side_effect = Exception("404 Client Error")  # Simulasikan error
        mock_get.return_value = mock_response

        # Pastikan fungsi raise error seperti yang diharapkan
        with self.assertRaises(Exception) as context:
            fetch_product_data(url)
        
        self.assertEqual(str(context.exception), '404 Client Error')

if __name__ == '__main__':
    unittest.main()