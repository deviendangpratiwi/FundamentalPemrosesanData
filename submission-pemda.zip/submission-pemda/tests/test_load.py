import sys
import os
import unittest
from unittest.mock import patch, MagicMock
import pandas as pd
from utils.load import save_to_csv, save_to_google_sheets

# Tambahkan path folder utama ke sys.path supaya bisa akses modul utils
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

class TestLoad(unittest.TestCase):

    @patch('utils.load.pd.DataFrame.to_csv')
    def test_save_to_csv(self, mock_to_csv):
        """Menguji apakah fungsi save_to_csv berhasil memanggil metode to_csv dengan benar."""
        # Siapkan data dummy
        df = pd.DataFrame({
            'title': ['Product 1', 'Product 2'],
            'price': [10000, 20000],
            'rating': [4.5, 5.0]
        })
        
        # Jalankan fungsi yang diuji
        save_to_csv(df, 'test.csv')
        
        # Pastikan fungsi .to_csv() dipanggil dengan argumen yang sesuai
        mock_to_csv.assert_called_once_with('test.csv', index=False)

    @patch('utils.load.build')
    @patch('utils.load.Credentials.from_service_account_file')
    def test_save_to_google_sheets(self, mock_creds, mock_build):
         """Menguji apakah fungsi save_to_google_sheets melakukan update ke Google Sheets."""
        # Siapkan DataFrame tiruan untuk pengujian
         df = pd.DataFrame({
            'title': ['Product 1', 'Product 2'],
            'price': [10000, 20000],
            'rating': [4.5, 5.0]
        })

       # Simulasikan proses autentikasi dan pembuatan service Google Sheets
         mock_creds.return_value = MagicMock()
         mock_service = MagicMock()
         mock_build.return_value = mock_service

       # Jalankan fungsi yang akan diuji
         save_to_google_sheets(df, 'spreadsheet_id')

       # Verifikasi bahwa fungsi .update() dipanggil satu kali
         mock_service.spreadsheets.return_value.values.return_value.update.assert_called_once()

if __name__ == '__main__':
    unittest.main()