import sys
import os
import unittest
import pandas as pd

# Tambahkan path direktori proyek ke dalam path sistem Python
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from utils.transform import clean_product_data  # Pastikan nama fungsinya sesuai

class TestTransform(unittest.TestCase):
    """Pengujian unit untuk fungsi clean_product_data di modul transform"""

    def test_clean_product_data(self):
        """Cek: Fungsi mampu membersihkan dan memformat data dengan tepat."""
        # Buat dataset tiruan
        products = [
    {'title': 'Kaos Santai', 'price': '15000', 'rating': '4.3', 'colors': '2', 'size': 'M', 'gender': 'Unisex'},
    {'title': 'Jaket Ringan', 'price': '30000', 'rating': '4.7', 'colors': '4', 'size': 'L', 'gender': 'Men'}
        ]
        
        # Jalankan fungsi yang diuji
        cleaned_df = clean_product_data(products)
        
        # Pastikan jumlah baris sesuai harapan
        self.assertEqual(len(cleaned_df), 2)
        
        # Kolom penting harus tetap ada setelah transformasi
        expected_columns = ['price', 'rating', 'timestamp']
        for col in expected_columns:
            self.assertIn(col, cleaned_df.columns)
        
        # Nilai-nilai numerik seharusnya valid (positif)
        self.assertTrue((cleaned_df['price'] > 0).all())
        self.assertTrue((cleaned_df['rating'] > 0).all())

    def test_unknown_product(self):
        """Cek: Produk dengan judul tidak sah dan harga invalid akan disaring."""
        # Data produk tidak valid (judul Unknown, harga tidak numerik)
        products = [
            {'title': 'Unknown Product', 'price': 'unknown', 'rating': '4.5', 'colors': '5', 'size': 'M', 'gender': 'Men'}
        ]
        
        cleaned_df = clean_product_data(products)
        
        # Harusnya hasil akhir kosong karena data tidak lolos validasi
        self.assertEqual(len(cleaned_df), 0)

if __name__ == '__main__':
    unittest.main()