import requests
from bs4 import BeautifulSoup

def fetch_product_data(url: str) -> list:
    """Scrape data produk dari halaman koleksi fashion."""

    try:
        # Mengirim request ke URL dan validasi responsenya
        res = requests.get(url, timeout=10)
        res.raise_for_status()
    except requests.exceptions.RequestException as error:
        raise Exception(f"Gagal mengakses URL {url}: {error}")

    try:
        soup = BeautifulSoup(res.text, 'html.parser')
        product_list = []

         # Cari semua elemen kartu produk di halaman
        cards = soup.find_all('div', class_='collection-card')
        for card in cards:
            # Proses pengambilan data per elemen produk
            title = card.find('h3', class_='product-title')
            price = card.find('div', class_='price-container')
            rating = card.find('p', string=lambda t: t and 'Rating' in t)
            colors = card.find('p', string=lambda t: t and 'Colors' in t)
            size = card.find('p', string=lambda t: t and 'Size' in t)
            gender = card.find('p', string=lambda t: t and 'Gender' in t)
            
            # Ambil informasi produk dan simpan sebagai dict
            product_info = {
                'title': title.text.strip() if title else 'Tanpa Judul',
                'price': price.text.strip() if price else 'Harga Tidak Diketahui',
                'rating': rating.text.strip() if rating else 'Tidak Ada Rating',
                'colors': colors.text.strip() if colors else 'Tidak Ada Info Warna',
                'size': size.text.strip() if size else 'Ukuran Tidak Dicantumkan',
                'gender': gender.text.strip() if gender else 'Tidak Ada Info Gender',
            }

            product_list.append(product_info)

        return product_list

    except Exception as error:
        raise Exception(f"Terjadi kesalahan saat membaca konten halaman: {error}")