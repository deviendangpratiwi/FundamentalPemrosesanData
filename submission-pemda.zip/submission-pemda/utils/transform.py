import pandas as pd
import numpy as np
from datetime import datetime
import warnings

# Hilangkan FutureWarning agar terminal lebih bersih
warnings.simplefilter(action='ignore', category=FutureWarning)

# Aktifkan pengaturan baru dari pandas agar konversi tipe data lebih eksplisit
pd.set_option('future.no_silent_downcasting', True)

def clean_product_data(product_list):
    """Melakukan proses pembersihan dan transformasi terhadap data produk mentah."""

    try:
        # Konversi list of dict menjadi DataFrame
        data_frame = pd.DataFrame(product_list)

        # Pastikan semua kolom penting tersedia
        required_columns = ['title', 'price', 'rating', 'colors', 'size', 'gender']
        for col in required_columns:
            if col not in data_frame.columns:
                raise KeyError(f"Kolom '{col}' tidak ditemukan dalam data mentah.")

        # Filter data yang judulnya tidak valid (produk tidak dikenal)
        data_frame = data_frame[data_frame['title'].str.lower() != 'unknown product']

        # Pembersihan kolom harga: hapus simbol & ubah ke float → konversi mata uang
        data_frame['price'] = data_frame['price'].replace(r'[^\d.]', '', regex=True)
        data_frame['price'] = data_frame['price'].replace('', np.nan)
        data_frame.dropna(subset=['price'], inplace=True)
        data_frame['price'] = data_frame['price'].astype(float) * 16000

        # Bersihkan kolom rating: simpan hanya angka & ubah ke float
        data_frame['rating'] = data_frame['rating'].replace(r'[^0-9.]', '', regex=True)
        data_frame['rating'] = data_frame['rating'].replace('', np.nan)
        data_frame.dropna(subset=['rating'], inplace=True)
        data_frame['rating'] = data_frame['rating'].astype(float)

        # Ambil jumlah warna dari teks dan ubah jadi integer
        data_frame['colors'] = data_frame['colors'].replace(r'\D', '', regex=True)
        data_frame['colors'] = data_frame['colors'].replace('', np.nan)
        data_frame.dropna(subset=['colors'], inplace=True)
        data_frame['colors'] = data_frame['colors'].astype(int)

        # Rapikan kolom size dan gender: buang label deskripsi di awal
        data_frame['size'] = data_frame['size'].replace(r'Size:\s*', '', regex=True)
        data_frame['gender'] = data_frame['gender'].replace(r'Gender:\s*', '', regex=True)

        # Buang data yang duplikat atau ada nilai kosong
        data_frame.drop_duplicates(inplace=True)
        data_frame.dropna(inplace=True)

        # Tambahkan kolom waktu proses dijalankan
        data_frame['timestamp'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

        return data_frame

    except Exception as e:
        print(f"[ERROR] Terjadi kesalahan saat membersihkan data produk: {e}")
        return pd.DataFrame() # return kosong agar program tidak berhenti total
