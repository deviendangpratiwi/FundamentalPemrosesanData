import pandas as pd
from google.oauth2.service_account import Credentials
from googleapiclient.discovery import build
from sqlalchemy import create_engine

def save_to_csv(data_frame, filename="products.csv"):
    """Ekspor data ke file CSV lokal untuk backup atau analisis offline."""
    data_frame.to_csv(filename, index=False)
    print(f"✅File CSV berhasil dibuat: {filename}.")

def save_to_google_sheets(data_frame, spreadsheet_id):
    """Upload DataFrame ke Google Sheets mulai dari sel A1, lengkap dengan header kolom."""
    try:
        # Autentikasi menggunakan file kredensial akun layanan
        creds = Credentials.from_service_account_file('google-sheets-api.json')
        service = build('sheets', 'v4', credentials=creds)
        sheet = service.spreadsheets()

        # Gabungkan header kolom dan isi data ke dalam satu list
        values = [list(data_frame.columns)] + data_frame.values.tolist()
        body = {'values': values}

        # Kirim data ke Sheet1 dimulai dari sel A1
        sheet.values().update(
            spreadsheetId=spreadsheet_id,
            range='Sheet1!A1',
            valueInputOption='RAW',
            body=body
        ).execute()

        print("✅Data berhasil diunggah ke Google Sheets.")
        
    except Exception as e:
        print(f" Gagal menyimpan data ke Google Sheets: {e}")


def load_to_postgresql(data_frame, table_name='products'):
    """Transfer data ke tabel PostgreSQL (akan ditimpa jika sudah ada)."""
    try:
        # Konfigurasi koneksi database
        username = 'postgres'
        password = 'etlsukses'
        host = 'localhost'
        port = '5432'
        database = 'etl_database'

        print("Mencoba koneksi ke database PostgreSQL...")
        
        # Buat engine SQLAlchemy untuk koneksi
        engine = create_engine(f'postgresql+psycopg2://{username}:{password}@{host}:{port}/{database}')
        
        print(f"Menyimpan {len(data_frame)} baris ke tabel '{table_name}'...")
        data_frame.to_sql(table_name, engine, if_exists='replace', index=False)

        print(f"✅Data berhasil dimasukkan ke tabel PostgreSQL '{table_name}'.")

    except Exception as e:
        print(f"Proses simpan ke PostgreSQL gagal: {e}")
